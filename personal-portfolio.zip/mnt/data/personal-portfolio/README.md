# Personal Portfolio Website

Full-stack portfolio website using React.js, Node.js/Express.js, and MongoDB.

## Features
- Home/About section
- Skills section
- Projects section loaded from backend API
- Contact form stored in MongoDB
- Clean responsive UI

## Tech Stack
- Frontend: React.js, CSS
- Backend: Node.js, Express.js
- Database: MongoDB

## How to Run

### 1. Backend
```bash
cd backend
npm install
npm run dev
```

Create a `.env` file inside backend:
```env
PORT=5000
MONGO_URI=mongodb://127.0.0.1:27017/portfolioDB
```

### 2. Frontend
```bash
cd frontend
npm install
npm run dev
```

Frontend runs on `http://localhost:5173`.
Backend runs on `http://localhost:5000`.
