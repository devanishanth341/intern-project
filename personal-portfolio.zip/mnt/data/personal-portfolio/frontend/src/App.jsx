import { useEffect, useState } from 'react';
import axios from 'axios';

const API_URL = 'http://localhost:5000/api';

function App() {
  const [projects, setProjects] = useState([]);
  const [form, setForm] = useState({ name: '', email: '', message: '' });
  const [status, setStatus] = useState('');

  useEffect(() => {
    axios.get(`${API_URL}/projects`)
      .then((res) => setProjects(res.data))
      .catch(() => setProjects([]));
  }, []);

  const handleChange = (e) => {
    setForm({ ...form, [e.target.name]: e.target.value });
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    try {
      await axios.post(`${API_URL}/contact`, form);
      setStatus('Message sent successfully!');
      setForm({ name: '', email: '', message: '' });
    } catch (error) {
      setStatus('Something went wrong. Try again.');
    }
  };

  return (
    <div>
      <nav className="navbar">
        <h2>DEVANISHANTH S G</h2>
        <div>
          <a href="#about">About</a>
          <a href="#skills">Skills</a>
          <a href="#projects">Projects</a>
          <a href="#contact">Contact</a>
        </div>
      </nav>

      <section className="hero">
        <h1>Hi, I am Devanishanth</h1>
        <p>Artificial Intelligence and Data Science Student</p>
        <a className="btn" href="#projects">View My Projects</a>
      </section>

      <section id="about" className="section">
        <h2>About Me</h2>
        <p>
          I am an AI and Data Science student interested in web development,
          machine learning, data analytics, and full-stack application development.
        </p>
      </section>

      <section id="skills" className="section">
        <h2>Skills</h2>
        <div className="skills">
          <span>HTML</span>
          <span>CSS</span>
          <span>JavaScript</span>
          <span>React.js</span>
          <span>Node.js</span>
          <span>Express.js</span>
          <span>MongoDB</span>
          <span>Python</span>
          <span>C++</span>
        </div>
      </section>

      <section id="projects" className="section">
        <h2>Projects</h2>
        <div className="project-grid">
          {projects.length === 0 ? (
            <p>No projects found. Add projects using backend API.</p>
          ) : (
            projects.map((project) => (
              <div className="project-card" key={project._id}>
                <h3>{project.title}</h3>
                <p>{project.description}</p>
                <p><b>Tech:</b> {project.technologies?.join(', ')}</p>
                {project.githubLink && <a href={project.githubLink}>GitHub</a>}
                {project.liveLink && <a href={project.liveLink}>Live Demo</a>}
              </div>
            ))
          )}
        </div>
      </section>

      <section id="contact" className="section">
        <h2>Contact Me</h2>
        <form onSubmit={handleSubmit} className="contact-form">
          <input name="name" placeholder="Your Name" value={form.name} onChange={handleChange} required />
          <input name="email" type="email" placeholder="Your Email" value={form.email} onChange={handleChange} required />
          <textarea name="message" placeholder="Your Message" value={form.message} onChange={handleChange} required />
          <button type="submit">Send Message</button>
        </form>
        <p>{status}</p>
      </section>

      <footer>
        <p>© 2026 Devanishanth S G | Personal Portfolio</p>
      </footer>
    </div>
  );
}

export default App;
