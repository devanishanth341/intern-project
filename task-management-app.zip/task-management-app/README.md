# TaskFlow - Task Management Web Application

A full-stack task management application for creating, updating, deleting, and tracking tasks.

## Features

- User registration and login
- JWT-based authentication and authorization
- Create, read, update, and delete tasks
- Task status tracking: Pending, In Progress, Completed
- Priority levels: Low, Medium, High
- Due date support
- Search and filter tasks
- Responsive design for desktop and mobile

## Tech Stack

- Frontend: HTML, CSS, JavaScript
- Backend: Node.js, Express.js
- Authentication: JWT, bcryptjs
- Storage: JSON file database for simple local development

## Folder Structure

```text
task-management-app/
├── backend/
│   ├── server.js
│   ├── package.json
│   ├── data.json
│   └── .env.example
├── frontend/
│   ├── index.html
│   ├── style.css
│   └── app.js
└── README.md
```

## How to Run

### 1. Start the Backend

```bash
cd backend
npm install
npm start
```

Backend will run at:

```text
http://localhost:5000
```

### 2. Start the Frontend

Open `frontend/index.html` directly in your browser.

Better option in VS Code:

- Install the Live Server extension
- Right-click `frontend/index.html`
- Click **Open with Live Server**

## API Endpoints

### Authentication

```text
POST /api/auth/register
POST /api/auth/login
```

### Tasks

```text
GET    /api/tasks
POST   /api/tasks
PUT    /api/tasks/:id
DELETE /api/tasks/:id
```

All task routes require this header:

```text
Authorization: Bearer YOUR_TOKEN
```

## Optional Upgrade Ideas

- Add MongoDB database
- Add WebSocket real-time updates using Socket.io
- Add task categories or labels
- Add admin role
- Deploy backend on Render and frontend on Netlify/Vercel
