const API_URL = 'http://localhost:5000/api';

const authSection = document.getElementById('authSection');
const dashboard = document.getElementById('dashboard');
const logoutBtn = document.getElementById('logoutBtn');
const loginTab = document.getElementById('loginTab');
const registerTab = document.getElementById('registerTab');
const authForm = document.getElementById('authForm');
const authSubmit = document.getElementById('authSubmit');
const authMessage = document.getElementById('authMessage');
const nameInput = document.getElementById('nameInput');
const emailInput = document.getElementById('emailInput');
const passwordInput = document.getElementById('passwordInput');
const welcomeTitle = document.getElementById('welcomeTitle');
const taskForm = document.getElementById('taskForm');
const taskTitle = document.getElementById('taskTitle');
const taskDescription = document.getElementById('taskDescription');
const taskDueDate = document.getElementById('taskDueDate');
const taskPriority = document.getElementById('taskPriority');
const taskStatus = document.getElementById('taskStatus');
const taskSubmit = document.getElementById('taskSubmit');
const cancelEdit = document.getElementById('cancelEdit');
const tasksList = document.getElementById('tasksList');
const searchInput = document.getElementById('searchInput');
const filterStatus = document.getElementById('filterStatus');
const totalCount = document.getElementById('totalCount');
const doneCount = document.getElementById('doneCount');

let isRegisterMode = false;
let tasks = [];
let editingTaskId = null;

function getToken() {
  return localStorage.getItem('taskflow_token');
}

function getUser() {
  return JSON.parse(localStorage.getItem('taskflow_user') || 'null');
}

function setAuth(token, user) {
  localStorage.setItem('taskflow_token', token);
  localStorage.setItem('taskflow_user', JSON.stringify(user));
}

function clearAuth() {
  localStorage.removeItem('taskflow_token');
  localStorage.removeItem('taskflow_user');
}

function toggleAuthMode(register) {
  isRegisterMode = register;
  registerTab.classList.toggle('active', register);
  loginTab.classList.toggle('active', !register);
  nameInput.classList.toggle('hidden', !register);
  nameInput.required = register;
  authSubmit.textContent = register ? 'Register' : 'Login';
  authMessage.textContent = '';
}

async function request(path, options = {}) {
  const headers = { 'Content-Type': 'application/json', ...(options.headers || {}) };
  const token = getToken();
  if (token) headers.Authorization = `Bearer ${token}`;

  const response = await fetch(`${API_URL}${path}`, { ...options, headers });
  const data = await response.json();

  if (!response.ok) {
    throw new Error(data.message || 'Something went wrong');
  }

  return data;
}

function showDashboard() {
  const user = getUser();
  authSection.classList.add('hidden');
  dashboard.classList.remove('hidden');
  logoutBtn.classList.remove('hidden');
  welcomeTitle.textContent = user ? `${user.name}'s Tasks` : 'My Tasks';
  loadTasks();
}

function showAuth() {
  authSection.classList.remove('hidden');
  dashboard.classList.add('hidden');
  logoutBtn.classList.add('hidden');
}

async function loadTasks() {
  try {
    tasks = await request('/tasks');
    renderTasks();
  } catch (error) {
    tasksList.innerHTML = `<div class="empty-state">${error.message}</div>`;
  }
}

function renderTasks() {
  const searchTerm = searchInput.value.toLowerCase();
  const status = filterStatus.value;

  const filteredTasks = tasks.filter((task) => {
    const matchesSearch = task.title.toLowerCase().includes(searchTerm) || task.description.toLowerCase().includes(searchTerm);
    const matchesStatus = status === 'All' || task.status === status;
    return matchesSearch && matchesStatus;
  });

  totalCount.textContent = `${tasks.length} Total`;
  doneCount.textContent = `${tasks.filter((task) => task.status === 'Completed').length} Done`;

  if (filteredTasks.length === 0) {
    tasksList.innerHTML = '<div class="empty-state">No tasks found. Add your first task.</div>';
    return;
  }

  tasksList.innerHTML = filteredTasks.map((task) => `
    <article class="task-card">
      <div>
        <h3>${escapeHTML(task.title)}</h3>
        <p>${escapeHTML(task.description || 'No description')}</p>
        <div class="meta">
          <span class="badge">${task.status}</span>
          <span class="badge">${task.priority}</span>
          <span class="badge">Due: ${task.dueDate || 'No date'}</span>
        </div>
      </div>
      <div class="actions">
        <button class="edit-btn" onclick="startEdit('${task.id}')">Edit</button>
        <button class="delete-btn" onclick="deleteTask('${task.id}')">Delete</button>
      </div>
    </article>
  `).join('');
}

function escapeHTML(text) {
  const div = document.createElement('div');
  div.textContent = text;
  return div.innerHTML;
}

window.startEdit = function (id) {
  const task = tasks.find((item) => item.id === id);
  if (!task) return;

  editingTaskId = id;
  taskTitle.value = task.title;
  taskDescription.value = task.description;
  taskDueDate.value = task.dueDate;
  taskPriority.value = task.priority;
  taskStatus.value = task.status;
  taskSubmit.textContent = 'Update Task';
  cancelEdit.classList.remove('hidden');
  taskTitle.focus();
};

window.deleteTask = async function (id) {
  if (!confirm('Delete this task?')) return;
  await request(`/tasks/${id}`, { method: 'DELETE' });
  loadTasks();
};

function resetTaskForm() {
  editingTaskId = null;
  taskForm.reset();
  taskPriority.value = 'Medium';
  taskStatus.value = 'Pending';
  taskSubmit.textContent = 'Add Task';
  cancelEdit.classList.add('hidden');
}

authForm.addEventListener('submit', async (event) => {
  event.preventDefault();
  authMessage.textContent = '';

  const endpoint = isRegisterMode ? '/auth/register' : '/auth/login';
  const payload = {
    email: emailInput.value,
    password: passwordInput.value
  };

  if (isRegisterMode) payload.name = nameInput.value;

  try {
    const data = await request(endpoint, {
      method: 'POST',
      body: JSON.stringify(payload)
    });
    setAuth(data.token, data.user);
    authForm.reset();
    showDashboard();
  } catch (error) {
    authMessage.textContent = error.message;
  }
});

taskForm.addEventListener('submit', async (event) => {
  event.preventDefault();

  const payload = {
    title: taskTitle.value,
    description: taskDescription.value,
    dueDate: taskDueDate.value,
    priority: taskPriority.value,
    status: taskStatus.value
  };

  if (editingTaskId) {
    await request(`/tasks/${editingTaskId}`, { method: 'PUT', body: JSON.stringify(payload) });
  } else {
    await request('/tasks', { method: 'POST', body: JSON.stringify(payload) });
  }

  resetTaskForm();
  loadTasks();
});

loginTab.addEventListener('click', () => toggleAuthMode(false));
registerTab.addEventListener('click', () => toggleAuthMode(true));
logoutBtn.addEventListener('click', () => {
  clearAuth();
  showAuth();
});
cancelEdit.addEventListener('click', resetTaskForm);
searchInput.addEventListener('input', renderTasks);
filterStatus.addEventListener('change', renderTasks);

if (getToken()) {
  showDashboard();
} else {
  showAuth();
}
