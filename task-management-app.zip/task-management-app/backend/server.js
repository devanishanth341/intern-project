const express = require('express');
const cors = require('cors');
const fs = require('fs');
const path = require('path');
const bcrypt = require('bcryptjs');
const jwt = require('jsonwebtoken');

const app = express();
const PORT = process.env.PORT || 5000;
const JWT_SECRET = process.env.JWT_SECRET || 'task-manager-secret-key';
const DB_PATH = path.join(__dirname, 'data.json');

app.use(cors());
app.use(express.json());

function readDB() {
  if (!fs.existsSync(DB_PATH)) {
    fs.writeFileSync(DB_PATH, JSON.stringify({ users: [], tasks: [] }, null, 2));
  }
  return JSON.parse(fs.readFileSync(DB_PATH, 'utf-8'));
}

function writeDB(data) {
  fs.writeFileSync(DB_PATH, JSON.stringify(data, null, 2));
}

function createToken(user) {
  return jwt.sign({ id: user.id, name: user.name, email: user.email }, JWT_SECRET, { expiresIn: '7d' });
}

function authMiddleware(req, res, next) {
  const header = req.headers.authorization;
  if (!header || !header.startsWith('Bearer ')) {
    return res.status(401).json({ message: 'Authorization token missing' });
  }

  try {
    req.user = jwt.verify(header.split(' ')[1], JWT_SECRET);
    next();
  } catch (error) {
    return res.status(401).json({ message: 'Invalid or expired token' });
  }
}

app.get('/', (req, res) => {
  res.json({ message: 'Task Management API is running' });
});

app.post('/api/auth/register', async (req, res) => {
  const { name, email, password } = req.body;

  if (!name || !email || !password) {
    return res.status(400).json({ message: 'Name, email, and password are required' });
  }

  if (password.length < 6) {
    return res.status(400).json({ message: 'Password must be at least 6 characters' });
  }

  const db = readDB();
  const existingUser = db.users.find((user) => user.email.toLowerCase() === email.toLowerCase());
  if (existingUser) {
    return res.status(409).json({ message: 'Email already registered' });
  }

  const hashedPassword = await bcrypt.hash(password, 10);
  const user = {
    id: Date.now().toString(),
    name,
    email: email.toLowerCase(),
    password: hashedPassword,
    createdAt: new Date().toISOString()
  };

  db.users.push(user);
  writeDB(db);

  const token = createToken(user);
  res.status(201).json({ token, user: { id: user.id, name: user.name, email: user.email } });
});

app.post('/api/auth/login', async (req, res) => {
  const { email, password } = req.body;

  if (!email || !password) {
    return res.status(400).json({ message: 'Email and password are required' });
  }

  const db = readDB();
  const user = db.users.find((item) => item.email.toLowerCase() === email.toLowerCase());
  if (!user) {
    return res.status(401).json({ message: 'Invalid email or password' });
  }

  const isMatch = await bcrypt.compare(password, user.password);
  if (!isMatch) {
    return res.status(401).json({ message: 'Invalid email or password' });
  }

  const token = createToken(user);
  res.json({ token, user: { id: user.id, name: user.name, email: user.email } });
});

app.get('/api/tasks', authMiddleware, (req, res) => {
  const db = readDB();
  const tasks = db.tasks
    .filter((task) => task.userId === req.user.id)
    .sort((a, b) => new Date(b.createdAt) - new Date(a.createdAt));
  res.json(tasks);
});

app.post('/api/tasks', authMiddleware, (req, res) => {
  const { title, description, status, priority, dueDate } = req.body;

  if (!title) {
    return res.status(400).json({ message: 'Task title is required' });
  }

  const db = readDB();
  const task = {
    id: Date.now().toString(),
    userId: req.user.id,
    title,
    description: description || '',
    status: status || 'Pending',
    priority: priority || 'Medium',
    dueDate: dueDate || '',
    createdAt: new Date().toISOString(),
    updatedAt: new Date().toISOString()
  };

  db.tasks.push(task);
  writeDB(db);
  res.status(201).json(task);
});

app.put('/api/tasks/:id', authMiddleware, (req, res) => {
  const db = readDB();
  const taskIndex = db.tasks.findIndex((task) => task.id === req.params.id && task.userId === req.user.id);

  if (taskIndex === -1) {
    return res.status(404).json({ message: 'Task not found' });
  }

  const oldTask = db.tasks[taskIndex];
  db.tasks[taskIndex] = {
    ...oldTask,
    title: req.body.title ?? oldTask.title,
    description: req.body.description ?? oldTask.description,
    status: req.body.status ?? oldTask.status,
    priority: req.body.priority ?? oldTask.priority,
    dueDate: req.body.dueDate ?? oldTask.dueDate,
    updatedAt: new Date().toISOString()
  };

  writeDB(db);
  res.json(db.tasks[taskIndex]);
});

app.delete('/api/tasks/:id', authMiddleware, (req, res) => {
  const db = readDB();
  const task = db.tasks.find((item) => item.id === req.params.id && item.userId === req.user.id);

  if (!task) {
    return res.status(404).json({ message: 'Task not found' });
  }

  db.tasks = db.tasks.filter((item) => item.id !== req.params.id);
  writeDB(db);
  res.json({ message: 'Task deleted successfully' });
});

app.listen(PORT, () => {
  console.log(`Server running on http://localhost:${PORT}`);
});
