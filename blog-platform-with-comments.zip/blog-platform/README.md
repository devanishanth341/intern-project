# Blog Platform with Comments

A full-stack blogging platform where users can register, login, create/edit/delete posts, and comment on posts.

## Tech Stack
- Frontend: HTML, CSS, JavaScript
- Backend: Node.js, Express.js
- Database: MongoDB with Mongoose
- Authentication: JWT

## Features
- User registration and login
- JWT-based authentication
- Create, read, update, delete blog posts
- Add and view comments
- Only the post owner can edit/delete their posts
- Responsive design for desktop and mobile

## Run Backend
```bash
cd backend
npm install
copy .env.example .env   # Windows
# or
cp .env.example .env     # Mac/Linux
npm start
```

Backend runs on: http://localhost:5000

## Run Frontend
Open this file in browser:
```text
frontend/index.html
```

## MongoDB
Use local MongoDB or MongoDB Atlas. Update the MONGO_URI in backend/.env.

Default local URI:
```text
mongodb://127.0.0.1:27017/blog_platform
```
