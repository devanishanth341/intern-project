const API_URL = 'http://localhost:5000/api';
let currentUser = JSON.parse(localStorage.getItem('blogUser')) || null;
let allPosts = [];

const authSection = document.getElementById('authSection');
const createPostSection = document.getElementById('createPostSection');
const userBox = document.getElementById('userBox');
const postsContainer = document.getElementById('postsContainer');

function authHeaders() {
  return currentUser ? { 'Authorization': `Bearer ${currentUser.token}` } : {};
}

function updateUI() {
  if (currentUser) {
    authSection.style.display = 'none';
    createPostSection.style.display = 'block';
    userBox.innerHTML = `Welcome, ${currentUser.name} <button class="logout" onclick="logout()">Logout</button>`;
  } else {
    authSection.style.display = 'block';
    createPostSection.style.display = 'none';
    userBox.innerHTML = 'Guest user';
  }
}

async function register(e) {
  e.preventDefault();
  const data = {
    name: document.getElementById('regName').value,
    email: document.getElementById('regEmail').value,
    password: document.getElementById('regPassword').value
  };
  const res = await fetch(`${API_URL}/auth/register`, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify(data)
  });
  const result = await res.json();
  if (!res.ok) return alert(result.message);
  currentUser = result;
  localStorage.setItem('blogUser', JSON.stringify(result));
  updateUI();
}

async function login(e) {
  e.preventDefault();
  const data = {
    email: document.getElementById('loginEmail').value,
    password: document.getElementById('loginPassword').value
  };
  const res = await fetch(`${API_URL}/auth/login`, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify(data)
  });
  const result = await res.json();
  if (!res.ok) return alert(result.message);
  currentUser = result;
  localStorage.setItem('blogUser', JSON.stringify(result));
  updateUI();
}

function logout() {
  currentUser = null;
  localStorage.removeItem('blogUser');
  updateUI();
  loadPosts();
}

async function loadPosts() {
  const res = await fetch(`${API_URL}/posts`);
  allPosts = await res.json();
  renderPosts();
}

function renderPosts() {
  const query = document.getElementById('searchInput').value.toLowerCase();
  const filtered = allPosts.filter(post =>
    post.title.toLowerCase().includes(query) || post.content.toLowerCase().includes(query)
  );

  postsContainer.innerHTML = filtered.length ? '' : '<p>No posts found.</p>';

  filtered.forEach(post => {
    const canEdit = currentUser && post.author && post.author._id === currentUser._id;
    const div = document.createElement('div');
    div.className = 'post';
    div.innerHTML = `
      <h2>${escapeHtml(post.title)}</h2>
      <div class="meta">By ${escapeHtml(post.author?.name || 'Unknown')} • ${new Date(post.createdAt).toLocaleString()}</div>
      <div class="content">${escapeHtml(post.content)}</div>
      <div class="actions" style="margin-top:14px;">
        <button class="small" onclick="openPost('${post._id}')">View Comments</button>
        ${canEdit ? `<button class="small" onclick='startEdit(${JSON.stringify(post)})'>Edit</button>` : ''}
        ${canEdit ? `<button class="small danger" onclick="deletePost('${post._id}')">Delete</button>` : ''}
      </div>
      <div class="comments" id="comments-${post._id}" style="display:none;"></div>
    `;
    postsContainer.appendChild(div);
  });
}

async function savePost(e) {
  e.preventDefault();
  if (!currentUser) return alert('Please login first');

  const id = document.getElementById('editingPostId').value;
  const data = {
    title: document.getElementById('postTitle').value,
    content: document.getElementById('postContent').value
  };

  const res = await fetch(`${API_URL}/posts${id ? '/' + id : ''}`, {
    method: id ? 'PUT' : 'POST',
    headers: { 'Content-Type': 'application/json', ...authHeaders() },
    body: JSON.stringify(data)
  });
  const result = await res.json();
  if (!res.ok) return alert(result.message);

  cancelEdit();
  loadPosts();
}

function startEdit(post) {
  document.getElementById('editingPostId').value = post._id;
  document.getElementById('postTitle').value = post.title;
  document.getElementById('postContent').value = post.content;
  document.getElementById('formTitle').textContent = 'Edit Blog Post';
  document.getElementById('savePostBtn').textContent = 'Update Post';
  document.getElementById('cancelEditBtn').style.display = 'inline-block';
  window.scrollTo({ top: 0, behavior: 'smooth' });
}

function cancelEdit() {
  document.getElementById('postForm').reset();
  document.getElementById('editingPostId').value = '';
  document.getElementById('formTitle').textContent = 'Create Blog Post';
  document.getElementById('savePostBtn').textContent = 'Publish Post';
  document.getElementById('cancelEditBtn').style.display = 'none';
}

async function deletePost(id) {
  if (!confirm('Delete this post?')) return;
  const res = await fetch(`${API_URL}/posts/${id}`, { method: 'DELETE', headers: authHeaders() });
  const result = await res.json();
  if (!res.ok) return alert(result.message);
  loadPosts();
}

async function openPost(id) {
  const box = document.getElementById(`comments-${id}`);
  if (box.style.display === 'block') {
    box.style.display = 'none';
    return;
  }

  const res = await fetch(`${API_URL}/posts/${id}`);
  const data = await res.json();
  box.style.display = 'block';
  box.innerHTML = `
    <h3>Comments</h3>
    ${currentUser ? `
      <form onsubmit="addComment(event, '${id}')">
        <input id="comment-input-${id}" placeholder="Write a comment..." required />
        <button class="small">Add Comment</button>
      </form>
    ` : '<p>Login to comment.</p>'}
    <div>${data.comments.map(c => `
      <div class="comment">
        <strong>${escapeHtml(c.author?.name || 'User')}:</strong> ${escapeHtml(c.text)}
        ${currentUser && c.author?._id === currentUser._id ? `<button class="small danger" onclick="deleteComment('${c._id}', '${id}')">Delete</button>` : ''}
      </div>
    `).join('') || '<p>No comments yet.</p>'}</div>
  `;
}

async function addComment(e, postId) {
  e.preventDefault();
  const input = document.getElementById(`comment-input-${postId}`);
  const res = await fetch(`${API_URL}/comments`, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json', ...authHeaders() },
    body: JSON.stringify({ postId, text: input.value })
  });
  const result = await res.json();
  if (!res.ok) return alert(result.message);
  openPost(postId);
  openPost(postId);
}

async function deleteComment(commentId, postId) {
  const res = await fetch(`${API_URL}/comments/${commentId}`, { method: 'DELETE', headers: authHeaders() });
  const result = await res.json();
  if (!res.ok) return alert(result.message);
  openPost(postId);
  openPost(postId);
}

function escapeHtml(text) {
  const div = document.createElement('div');
  div.textContent = text || '';
  return div.innerHTML;
}

document.getElementById('registerForm').addEventListener('submit', register);
document.getElementById('loginForm').addEventListener('submit', login);
document.getElementById('postForm').addEventListener('submit', savePost);
document.getElementById('cancelEditBtn').addEventListener('click', cancelEdit);
document.getElementById('searchInput').addEventListener('input', renderPosts);

updateUI();
loadPosts();
