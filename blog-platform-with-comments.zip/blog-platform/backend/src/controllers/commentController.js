const Post = require('../models/Post');
const Comment = require('../models/Comment');

exports.addComment = async (req, res) => {
  const { postId, text } = req.body;
  const post = await Post.findById(postId);
  if (!post) return res.status(404).json({ message: 'Post not found' });

  const comment = await Comment.create({ text, post: postId, author: req.user._id });
  const populatedComment = await comment.populate('author', 'name email');
  res.status(201).json(populatedComment);
};

exports.deleteComment = async (req, res) => {
  const comment = await Comment.findById(req.params.id);
  if (!comment) return res.status(404).json({ message: 'Comment not found' });

  if (comment.author.toString() !== req.user._id.toString()) {
    return res.status(403).json({ message: 'You can delete only your own comments' });
  }

  await comment.deleteOne();
  res.json({ message: 'Comment deleted' });
};
