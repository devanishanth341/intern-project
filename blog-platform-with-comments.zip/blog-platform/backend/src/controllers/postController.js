const Post = require('../models/Post');
const Comment = require('../models/Comment');

exports.getPosts = async (req, res) => {
  const posts = await Post.find().populate('author', 'name email').sort({ createdAt: -1 });
  res.json(posts);
};

exports.getPost = async (req, res) => {
  const post = await Post.findById(req.params.id).populate('author', 'name email');
  if (!post) return res.status(404).json({ message: 'Post not found' });

  const comments = await Comment.find({ post: post._id }).populate('author', 'name email').sort({ createdAt: -1 });
  res.json({ post, comments });
};

exports.createPost = async (req, res) => {
  const { title, content } = req.body;
  const post = await Post.create({ title, content, author: req.user._id });
  const populatedPost = await post.populate('author', 'name email');
  res.status(201).json(populatedPost);
};

exports.updatePost = async (req, res) => {
  const post = await Post.findById(req.params.id);
  if (!post) return res.status(404).json({ message: 'Post not found' });
  if (post.author.toString() !== req.user._id.toString()) {
    return res.status(403).json({ message: 'You can update only your own posts' });
  }

  post.title = req.body.title || post.title;
  post.content = req.body.content || post.content;
  await post.save();
  const populatedPost = await post.populate('author', 'name email');
  res.json(populatedPost);
};

exports.deletePost = async (req, res) => {
  const post = await Post.findById(req.params.id);
  if (!post) return res.status(404).json({ message: 'Post not found' });
  if (post.author.toString() !== req.user._id.toString()) {
    return res.status(403).json({ message: 'You can delete only your own posts' });
  }

  await Comment.deleteMany({ post: post._id });
  await post.deleteOne();
  res.json({ message: 'Post and related comments deleted' });
};
