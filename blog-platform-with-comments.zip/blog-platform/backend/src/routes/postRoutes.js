const express = require('express');
const { protect } = require('../middleware/authMiddleware');
const { getPosts, getPost, createPost, updatePost, deletePost } = require('../controllers/postController');

const router = express.Router();
router.get('/', getPosts);
router.get('/:id', getPost);
router.post('/', protect, createPost);
router.put('/:id', protect, updatePost);
router.delete('/:id', protect, deletePost);

module.exports = router;
