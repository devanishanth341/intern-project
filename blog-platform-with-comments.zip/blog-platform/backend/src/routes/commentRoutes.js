const express = require('express');
const { protect } = require('../middleware/authMiddleware');
const { addComment, deleteComment } = require('../controllers/commentController');

const router = express.Router();
router.post('/', protect, addComment);
router.delete('/:id', protect, deleteComment);

module.exports = router;
