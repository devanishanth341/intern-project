require('dotenv').config();
const connectDB = require('./config/db');
const User = require('./models/User');
const Product = require('./models/Product');

async function seed() {
  await connectDB();
  await User.deleteMany();
  await Product.deleteMany();

  await User.create([
    { name: 'Admin', email: 'admin@example.com', password: 'admin123', role: 'admin' },
    { name: 'User', email: 'user@example.com', password: 'user123', role: 'user' }
  ]);

  await Product.create([
    { name: 'Wireless Mouse', description: 'Ergonomic mouse with smooth scrolling.', price: 699, category: 'Electronics', stock: 25, imageUrl: 'https://images.unsplash.com/photo-1527864550417-7fd91fc51a46?w=600' },
    { name: 'Mechanical Keyboard', description: 'RGB keyboard for coding and gaming.', price: 2499, category: 'Electronics', stock: 12, imageUrl: 'https://images.unsplash.com/photo-1587829741301-dc798b83add3?w=600' },
    { name: 'Laptop Backpack', description: 'Water-resistant backpack with laptop sleeve.', price: 1199, category: 'Accessories', stock: 30, imageUrl: 'https://images.unsplash.com/photo-1553062407-98eeb64c6a62?w=600' },
    { name: 'Smart Watch', description: 'Fitness tracking and notifications.', price: 3499, category: 'Wearables', stock: 15, imageUrl: 'https://images.unsplash.com/photo-1523275335684-37898b6baf30?w=600' }
  ]);

  console.log('Seed completed');
  process.exit();
}

seed().catch(err => {
  console.error(err);
  process.exit(1);
});
