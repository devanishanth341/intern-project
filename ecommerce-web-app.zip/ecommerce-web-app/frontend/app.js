const API = 'http://localhost:5000/api';
let token = localStorage.getItem('token') || '';
let currentUser = JSON.parse(localStorage.getItem('user') || 'null');
let cart = JSON.parse(localStorage.getItem('cart') || '[]');
let productsCache = [];

function toast(msg) {
  const t = document.getElementById('toast');
  t.textContent = msg;
  t.style.display = 'block';
  setTimeout(() => t.style.display = 'none', 2600);
}

function headers() {
  return { 'Content-Type': 'application/json', Authorization: `Bearer ${token}` };
}

function showSection(id) {
  ['auth', 'products', 'cart', 'orders', 'admin'].forEach(s => document.getElementById(s).classList.add('hidden'));
  document.getElementById(id).classList.remove('hidden');
  if (id === 'products') loadProducts();
  if (id === 'cart') renderCart();
  if (id === 'orders') loadOrders();
  if (id === 'admin') { loadProducts(); loadAdminOrders(); }
}

function syncUI() {
  document.getElementById('logoutBtn').classList.toggle('hidden', !token);
  document.getElementById('adminBtn').classList.toggle('hidden', !(currentUser && currentUser.role === 'admin'));
  document.getElementById('cartCount').textContent = cart.reduce((sum, item) => sum + item.quantity, 0);
  showSection(token ? 'products' : 'auth');
}

async function register() {
  const body = {
    name: document.getElementById('regName').value,
    email: document.getElementById('regEmail').value,
    password: document.getElementById('regPassword').value,
    role: document.getElementById('regRole').value
  };
  const res = await fetch(`${API}/auth/register`, { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify(body) });
  const data = await res.json();
  if (!res.ok) return toast(data.message || 'Registration failed');
  saveSession(data);
}

async function login() {
  const body = { email: document.getElementById('loginEmail').value, password: document.getElementById('loginPassword').value };
  const res = await fetch(`${API}/auth/login`, { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify(body) });
  const data = await res.json();
  if (!res.ok) return toast(data.message || 'Login failed');
  saveSession(data);
}

function saveSession(data) {
  token = data.token;
  currentUser = data.user;
  localStorage.setItem('token', token);
  localStorage.setItem('user', JSON.stringify(currentUser));
  toast(`Welcome ${currentUser.name}`);
  syncUI();
}

function logout() {
  token = '';
  currentUser = null;
  cart = [];
  localStorage.clear();
  syncUI();
}

async function loadProducts() {
  const search = document.getElementById('search')?.value || '';
  const res = await fetch(`${API}/products?search=${encodeURIComponent(search)}`);
  productsCache = await res.json();
  const grid = document.getElementById('productGrid');
  grid.innerHTML = productsCache.map(p => `
    <article class="product">
      <img src="${p.imageUrl || 'https://via.placeholder.com/500x300?text=Product'}" alt="${p.name}">
      <div class="content">
        <span class="badge">${p.category}</span>
        <h3>${p.name}</h3>
        <p>${p.description}</p>
        <div class="price">₹${p.price}</div>
        <small>Stock: ${p.stock}</small>
        <button onclick="addToCart('${p._id}')" ${p.stock <= 0 ? 'disabled' : ''}>Add to Cart</button>
        ${currentUser?.role === 'admin' ? `<button onclick="deleteProduct('${p._id}')" style="background:#dc2626;margin-top:8px">Delete</button>` : ''}
      </div>
    </article>`).join('');
}

function addToCart(id) {
  const product = productsCache.find(p => p._id === id);
  const item = cart.find(i => i.productId === id);
  if (item) item.quantity += 1;
  else cart.push({ productId: id, name: product.name, price: product.price, quantity: 1 });
  localStorage.setItem('cart', JSON.stringify(cart));
  syncUI();
  toast('Added to cart');
}

function renderCart() {
  const el = document.getElementById('cartItems');
  if (!cart.length) el.innerHTML = '<p>Your cart is empty.</p>';
  else el.innerHTML = cart.map((i, idx) => `
    <div class="cart-row">
      <div><b>${i.name}</b><br>₹${i.price} × ${i.quantity}</div>
      <div>
        <button onclick="changeQty(${idx}, -1)">-</button>
        <button onclick="changeQty(${idx}, 1)">+</button>
        <button onclick="removeItem(${idx})" style="background:#dc2626">Remove</button>
      </div>
    </div>`).join('');
  document.getElementById('cartTotal').textContent = cart.reduce((sum, i) => sum + i.price * i.quantity, 0);
}

function changeQty(idx, diff) {
  cart[idx].quantity += diff;
  if (cart[idx].quantity <= 0) cart.splice(idx, 1);
  localStorage.setItem('cart', JSON.stringify(cart));
  syncUI();
  renderCart();
}

function removeItem(idx) {
  cart.splice(idx, 1);
  localStorage.setItem('cart', JSON.stringify(cart));
  syncUI();
  renderCart();
}

async function checkout() {
  const shippingAddress = document.getElementById('address').value.trim();
  if (!shippingAddress) return toast('Enter shipping address');
  const res = await fetch(`${API}/orders`, {
    method: 'POST', headers: headers(),
    body: JSON.stringify({ shippingAddress, items: cart })
  });
  const data = await res.json();
  if (!res.ok) return toast(data.message || 'Checkout failed');
  cart = [];
  localStorage.setItem('cart', '[]');
  toast('Order placed successfully');
  syncUI();
  showSection('orders');
}

async function loadOrders() {
  const res = await fetch(`${API}/orders/my`, { headers: headers() });
  const data = await res.json();
  document.getElementById('orderList').innerHTML = data.length ? data.map(orderCard).join('') : '<p>No orders yet.</p>';
}

function orderCard(o, admin = false) {
  return `<div class="order">
    <div>
      <b>Order #${o._id.slice(-6)}</b><br>
      Items: ${o.items.map(i => `${i.name} × ${i.quantity}`).join(', ')}<br>
      Total: ₹${o.totalAmount}<br>
      Address: ${o.shippingAddress}<br>
      Status: <b>${o.status}</b>
      ${admin && o.user ? `<br>User: ${o.user.name} (${o.user.email})` : ''}
    </div>
    ${admin ? `<select onchange="updateStatus('${o._id}', this.value)">
      ${['Placed','Packed','Shipped','Delivered','Cancelled'].map(s => `<option ${o.status === s ? 'selected' : ''}>${s}</option>`).join('')}
    </select>` : ''}
  </div>`;
}

async function createProduct() {
  const body = {
    name: document.getElementById('pName').value,
    description: document.getElementById('pDesc').value,
    price: Number(document.getElementById('pPrice').value),
    stock: Number(document.getElementById('pStock').value),
    category: document.getElementById('pCategory').value,
    imageUrl: document.getElementById('pImage').value
  };
  const res = await fetch(`${API}/products`, { method: 'POST', headers: headers(), body: JSON.stringify(body) });
  const data = await res.json();
  if (!res.ok) return toast(data.message || 'Could not add product');
  toast('Product added');
  loadProducts();
}

async function deleteProduct(id) {
  const res = await fetch(`${API}/products/${id}`, { method: 'DELETE', headers: headers() });
  const data = await res.json();
  toast(data.message || 'Deleted');
  loadProducts();
}

async function loadAdminOrders() {
  const res = await fetch(`${API}/orders`, { headers: headers() });
  const data = await res.json();
  document.getElementById('adminOrders').innerHTML = Array.isArray(data) && data.length ? data.map(o => orderCard(o, true)).join('') : '<p>No orders.</p>';
}

async function updateStatus(id, status) {
  const res = await fetch(`${API}/orders/${id}/status`, { method: 'PATCH', headers: headers(), body: JSON.stringify({ status }) });
  const data = await res.json();
  if (!res.ok) return toast(data.message || 'Update failed');
  toast('Order status updated');
  loadAdminOrders();
}

syncUI();
