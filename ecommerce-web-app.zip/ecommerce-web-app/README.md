# E-Commerce Web Application

A full-stack starter online store with product catalog, cart, checkout, user/admin login, role-based access, backend APIs, MongoDB database integration, and order tracking.

## Tech Stack

- Frontend: HTML, CSS, JavaScript
- Backend: Node.js, Express.js
- Database: MongoDB using Mongoose
- Auth: JWT + bcrypt password hashing

## Features

- User registration and login
- Role-based access: Admin and User
- Product catalog with search
- Add to cart and cart quantity updates
- Checkout with shipping address
- User order tracking
- Admin product creation/deletion
- Admin order status updates
- Responsive design for desktop and mobile

## Folder Structure

```text
ecommerce-web-app/
├── backend/
│   ├── src/
│   │   ├── config/
│   │   ├── controllers/
│   │   ├── middleware/
│   │   ├── models/
│   │   ├── routes/
│   │   ├── seed.js
│   │   └── server.js
│   └── package.json
└── frontend/
    ├── index.html
    ├── style.css
    └── app.js
```

## How to Run

### 1. Start MongoDB

Install MongoDB locally or use MongoDB Atlas.

### 2. Run Backend

```bash
cd backend
npm install
copy .env.example .env
npm run seed
npm start
```

For Mac/Linux, use:

```bash
cp .env.example .env
```

Backend runs at:

```text
http://localhost:5000
```

### 3. Run Frontend

Open this file in browser:

```text
frontend/index.html
```

Or use VS Code Live Server extension.

## Demo Accounts

```text
Admin:
email: admin@example.com
password: admin123

User:
email: user@example.com
password: user123
```

## API Endpoints

### Auth

```text
POST /api/auth/register
POST /api/auth/login
GET  /api/auth/me
```

### Products

```text
GET    /api/products
GET    /api/products/:id
POST   /api/products        Admin only
PUT    /api/products/:id    Admin only
DELETE /api/products/:id    Admin only
```

### Orders

```text
POST  /api/orders              User/Admin
GET   /api/orders/my           User/Admin own orders
GET   /api/orders              Admin only
PATCH /api/orders/:id/status   Admin only
```

## Expected Learning Outcome

This project teaches full-stack application structure, REST API integration, JWT authentication, role-based authorization, database models, dynamic product rendering, cart state handling, checkout logic, and order tracking.
